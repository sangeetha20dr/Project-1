<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
    $name=$_POST['name'];
    $dateofbirth=$_POST['dateofbirth'];
    $gender=$_POST['gender'];
    $address=$_POST['address'];
    $adhar=$_POST['adhar'];
    $phonenumber=$_POST['phonenumber'];
    $username=$_POST['username'];
    $email=$_POST['email'];
    $password =$_POST['password'];#password_hash($_POST['password'],PASSWORD_BCRYPT);
    include 'my.php';
    $query = "SELECT * FROM regi WHERE email = '$email'";
    $result = $conn->query($query);
    if ($result->num_rows > 0) 
    {
        $message="Email is already registered. Please use a different email!";
    }
    else
    {
    $sql="INSERT INTO regi(name,dateofbirth,gender,address,adhar,phonenumber,username,email,password)
    VALUES('$name','$dateofbirth','$gender','$address','$adhar','$phonenumber','$username','$email','$password')";
    if(mysqli_query($conn,$sql))
{
$alt="sucessfully submitted ";
}
else
{
echo "Error:".$sql."<br>".mysqli_error($conn);
}
    }
mysqli_close($conn);
}
?>

<html>
    <head>
        <title>Alert</title>
</head>
        <body>
            <script>
                var alertmessage = "<?php echo $message; ?>"
                alert (alertmessage);
                window.location.href = "register.html";
                </script>
               <script>
                var altmessage = "<?php echo $alt; ?>"
                alert (altmessage);
                window.location.href = "login.html";
                </script>
        </body>
</html>       

