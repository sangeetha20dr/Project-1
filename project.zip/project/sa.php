<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Transparent Login Form with Blur Background</title>
	<link href="register.css" rel="stylesheet">
</head>
<body>
    <div class="contact-form">
       <form>
        <h1>Sign UP</h1>
            <div class="input-group">
                <label for="name" class="input-label">Name*</label>
                <input type="text" id="name" class="input-field" required>
            </div>
            <div class="input-group">
                <label for="address" class="input-label">Address*</label>
                <input type="text" id="address" class="input-field" required>
            </div>
            <div class="input-group">
                <label for="adhar number" class="input-label">Adhar Number*</label>
                <input type="number" id="adhar number" class="input-field" required>
            </div>
            <div class="input-group">
                <label for="phone number" class="input-label">Phone Number*</label>
                <input type="number" id="phone number" class="input-field" required>
            </div>
            <div class="input-group">
                <label for="username" class="input-label">Username*</label>
                <input type="text" id="username" class="input-field" required>
            </div>
            <div class="input-group">
                <label for="E-mail" class="input-label">E-mail*</label>
                <input type="text" id="email" class="input-field" required>
            </div>
            <div class="input-group">
                <label for="password" class="input-label">Password*</label>
                <input type="password" id="password" class="input-field" required>
            </div>
            <div class="input-group">
                <label for=" confirm password" class="input-label">confirm Password*</label>
                <input type="password" id="password" class="input-field" required>
            </div>
            <div class="input-group">
                <label for="Village" class="input-label">Village*</label>
                <input type="text" id="village" class="input-field" required>
            </div>
            <center>
          <h1><button type="submit">SIGN UP</button></h1>
            </center>
        </form>
    </div>
</center>
</body>
</html>
