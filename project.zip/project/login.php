<?php
include ("my.php");
$email=$_POST['email'];
$password=$_POST['password'];#//password_hash($_POST['password'],PASSWORD_BCRYPT);
$query="SELECT email,password FROM regi where email = '$email' and password='$password'  ";


#echo "Query : $query ";
$result =  $conn->query($query);
if ($result->num_rows > 0) {
   echo "login Sucess ";
    header("Location: home1.php");
}else{
    $alt="login failed ";
}
?>
<html>
    <body>
        <script>
            var altmsg = "<?php echo $alt?>";
            window.location.href = "login.html";
        </script>
   </body>
</html>